A stunning and responsive cosmetic E-commerce website, (tribute to NIVEA) from scratch using HTML, CSS and Javascrip
